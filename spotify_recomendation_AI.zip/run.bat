@echo off
echo ============================================================
echo   Spotify Song Recommendation System - Startup Script
echo   BTech CSE Mini Project
echo ============================================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not on PATH.
    echo Please install Python 3.9+ from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

echo [OK] Python found:
python --version
echo.

REM Create virtual environment if it doesn't exist
if not exist "venv\" (
    echo [INFO] Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
    echo [OK] Virtual environment created.
) else (
    echo [OK] Virtual environment already exists.
)
echo.

REM Activate virtual environment
echo [INFO] Activating virtual environment...
call venv\Scripts\activate.bat
if errorlevel 1 (
    echo [ERROR] Failed to activate virtual environment.
    pause
    exit /b 1
)
echo [OK] Virtual environment activated.
echo.

REM Install requirements
echo [INFO] Installing required packages (this may take a few minutes)...
pip install -r requirements.txt -q
if errorlevel 1 (
    echo [ERROR] Failed to install packages.
    pause
    exit /b 1
)
echo [OK] All packages installed.
echo.

REM Check dataset
if not exist "data\spotify_dataset.csv" (
    echo [ERROR] Dataset not found at data\spotify_dataset.csv
    echo Please ensure the dataset file is in the data\ folder.
    pause
    exit /b 1
)
echo [OK] Dataset found.
echo.

REM Create output directories
mkdir outputs\plots\clustering 2>nul
mkdir outputs\results 2>nul
mkdir models 2>nul

echo ============================================================
echo   Starting Streamlit Application...
echo   The app will open in your browser automatically.
echo   Press Ctrl+C to stop the server.
echo ============================================================
echo.

streamlit run app.py --server.headless false --browser.gatherUsageStats false
